# JADパッチ（root公開用）

このZIPをリポジトリに**そのまま上書きアップロード**してください。

- `pdfs/index.html` … PDFアーカイブ本体（自動ソート & LATESTバッジ）。
  - デフォルト `LATEST_FILE = "manual_v1.4.1.pdf"` にしてあります。`manual_final.pdf` を置いたら変更OK。
- `docs/index.html` … `/docs/` を直打ちした人を `../pdfs/` に自動転送。
- `images/index.html` … `/images/` 直打ちの404回避（簡易ページ）。

## 反映手順（root公開）
1. GitHub のリポジトリで **Add files → Upload files** を押す
2. このZIPを**ドラッグ&ドロップ**（同名ファイルは上書きでOK）
3. Commit changes
4. トップページの「PDFアーカイブ」リンクの href を `pdfs/` に修正（`docs/` ではありません）

---
迷ったら JAD へ。